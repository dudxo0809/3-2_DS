#pragma once
#include "UserListNode.h"
#include "AccountQueueNode.h"
#include "AccountBST.h"
#include <fstream>
using namespace std;

class UserList
{
private:
	UserListNode* Root;
	UserListNode* tail;

public:
	UserList();
	~UserList();

	UserListNode* GetRoot();
	AccountBSTNode* Insert(AccountQueueNode* node, AccountBST* bst);
	bool Search(char* name);
	bool Delete_Account(char* id);
	bool Print_L(UserListNode* node);
	
};
