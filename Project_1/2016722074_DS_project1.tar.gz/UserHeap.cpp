#include "UserHeap.h"

UserHeap::UserHeap()
{
    UserHeapNode* node = new UserHeapNode();
    Heap.push_back(node);   // for easy indexing
}

UserHeap::~UserHeap()
{
    
}

bool UserHeap::Insert(int agegroup)
{
    agegroup = 10 * (agegroup/10);
    //HLOAD
    for(int i=1;i<Heap.size();i++){
        if(Heap[i]->GetAgeGroup() == agegroup){
            Heap[i]->SetNumUser(Heap[i]->GetNumUser() +1);
            // sort Max heap
            int num = Heap[i]->GetNumUser();
            int idx = i;
            while(idx != 1 && num >= Heap[idx/2]->GetNumUser()){
                Heap[idx] = Heap[idx/2];
                idx /= 2;
            }


            return true;
        }
    }

    UserHeapNode* newNode = new UserHeapNode;   // make new node
    newNode->SetAgeGroup(agegroup);
    Heap.push_back(newNode);
    
    
   return true;
}

void UserHeap::Print()
{
    //PRINT H
    ofstream flog;
    flog.open("log.txt", ios::app);
    flog << "======== PRINT ========\n";
    flog << "Heap\n";
    for(int i=1;i<Heap.size();i++){     // traverse vector
        flog << Heap[i]->GetNumUser() << '/' << Heap[i]->GetAgeGroup() <<'\n';
    }
    flog << "=======================\n";
    flog.close();
}