#include "AccountQueueNode.h"

AccountQueueNode::AccountQueueNode()
{
    User_Name = new char[50];
    User_Id = new char[50];

    User_age = -1;
    pNext = nullptr;
    // memalloc & initialize
}

AccountQueueNode::~AccountQueueNode()
{   // deallocate mem
    delete[] User_Name;
    delete[] User_Id;
}

char* AccountQueueNode::GetName()
{
    return User_Name;
}

int AccountQueueNode::GetAge()
{
    return User_age;
}

char* AccountQueueNode::GetId()
{
    return User_Id;
}
AccountQueueNode* AccountQueueNode::GetNext()
{
    if(pNext == nullptr){      // return next account
        return nullptr;
    }else{
        return pNext;
    }
}
void AccountQueueNode::SetName(char* name)
{
    memcpy(User_Name, name, sizeof(char)*50);
}

void AccountQueueNode::SetAge(int age)
{
    User_age = age;
}

void AccountQueueNode::SetId(char* id)
{
    memcpy(User_Id, id, sizeof(char) * 50);
}

void AccountQueueNode::SetNext(AccountQueueNode* node)
{
    pNext = node;
}