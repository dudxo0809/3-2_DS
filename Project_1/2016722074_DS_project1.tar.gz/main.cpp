#include "Manager.h"

int main()
{
	Manager manager;
	manager.run("command.txt");		// run Program

	

	return 0;
}
