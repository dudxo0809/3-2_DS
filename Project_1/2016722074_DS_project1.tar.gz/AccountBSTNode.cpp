#include "AccountBSTNode.h"

AccountBSTNode::AccountBSTNode()
{
    Id = new char[50];  
    Name = new char[50];
    // Initialize
    SetLeft(nullptr);
    SetRight(nullptr);
    SetNext(nullptr);
}

AccountBSTNode::~AccountBSTNode()
{
    delete[] Id;    // deallocate mem
    delete[] Name;
}

char* AccountBSTNode::GetName()
{
    return Name;
}

char* AccountBSTNode::GetId()
{
    return Id;
}

AccountBSTNode* AccountBSTNode::GetLeft()
{
    return pLeft;
}

AccountBSTNode* AccountBSTNode::GetRight()
{
    return pRight;
}

AccountBSTNode* AccountBSTNode::GetNext()
{
    return pNext;
}
// Set value
void AccountBSTNode::SetName(char* name)
{
    memcpy(Name, name, sizeof(name));
}

void AccountBSTNode::SetId(char* id)
{
    memcpy(Id, id, sizeof(id));
}

void AccountBSTNode::SetLeft(AccountBSTNode* node)
{
    pLeft = node;
}

void AccountBSTNode::SetRight(AccountBSTNode* node)
{
    pRight = node;
}
void AccountBSTNode::SetNext(AccountBSTNode* node)
{
    pNext = node;
}