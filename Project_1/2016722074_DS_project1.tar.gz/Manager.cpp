#include "Manager.h"
#include <iostream>

Manager::Manager()
{   // make data structure
    ds_queue = new AccountQueue;
    ds_bst = new AccountBST;
    ds_heap = new UserHeap;
    ds_list = new UserList;

}

Manager::~Manager()
{   // deallocate
    delete ds_queue;
    delete ds_bst;
    delete ds_heap;
    delete ds_list;

}

void Manager::run(const char* command)
{
    fin.open(command, ios::app);
    // open command.txt file
    if (!fin)
    {
        flog.open("log.txt", ios::app);
        flog << "File Open Error" << endl;
        flog.close();
        
        return;
    }

    while (!fin.eof())
    {   
        char _cmd[50];
        string cmd;
        
        //getline(fin, cmd);
        fin.getline(_cmd, sizeof(_cmd));
        cmd = _cmd;

        string v[10];
        // toknize command
        size_t prev = 0, current;
        current = cmd.find(' ');
        int cnt = 0;
        while(current != string::npos){
            string sub = cmd.substr(prev, current - prev);
            v[cnt] = sub;
            prev = current + 1;
            current = cmd.find(' ', prev);
            cnt++;
        } 
        v[cnt] = cmd.substr(prev, current - prev);
        // has no command
        if(v[0].length() <= 0)
            break;

        if(v[0] == "QLOAD"){ 
            
            if(!QLOAD_Check)
            {
                QLOAD();
                QLOAD_Check = true;
                // if QLOAD already did
                // can't do QLOAD
            }
            else
            {
                PrintErrorCode(100);
            }
        }
        else if(v[0] == "ADD"){
            if(ADD(v)){
                //PrintSuccess("ADD");

            }
            else{
                PrintErrorCode(200);
            }
        }
        else if(v[0] == "QPOP"){

           
            if(QPOP(v)){
               PrintSuccess("QPOP");
            }
            else{
                PrintErrorCode(300);
            }
        }
        else if(v[0] == "SEARCH"){
            if(SEARCH(v)){
               PrintSuccess("SEARCH");
            }
            else{
               PrintErrorCode(400);
            }
        }
        else if(v[0] ==  "PRINT"){
           if(PRINT(v)){
               //PrintSuccess("PRINT");
           }
           else{
               PrintErrorCode(500);
           }
       }
       else if(v[0] == "DELETE"){
           if(DELETE(v)){
               PrintSuccess("DELETE");
           }
           else{
               PrintErrorCode(600);
           }
       }
       else if(v[0] == "HLOAD"){
           if(HLOAD()){
               PrintSuccess("HLOAD");
           }
           else{
               PrintErrorCode(700);
           }
       }
       else if(v[0] == "EXIT"){
            PrintSuccess("EXIT");
            break;
       }
       else{
           PrintErrorCode(800);
       }


    }
    fin.close();
    
}

bool Manager::QLOAD()
{
    ifstream fdata;

    fdata.open("data.txt", ios::app);
    flog.open("log.txt", ios::app);

    flog << "=========QLOAD=========\n";

    char cmd[32];

    while(!fdata.eof()){    // get all user data

        int cnt = 0;

        fdata.getline(cmd, 50);
        char* str = new char[50];
        char* temp = new char[50];


        strcpy(str, cmd);
        // make new account node
        AccountQueueNode* newNode = new AccountQueueNode;
        // toknize data
        char* ptr = strtok(str, " ");
        if(ptr==NULL)
            continue;
        while(ptr!=NULL){

            if(cnt==0){
                newNode->SetName(ptr);
            }
            else if(cnt==1){
                newNode->SetAge(atoi(ptr));
            }
            else if(cnt == 2){
                newNode->SetId(ptr);
            }
            
            cnt++;
            strcat(temp, ptr);
            strcat(temp, " ");
            //flog << ptr << ' ';
            ptr = strtok(NULL, " ");

            
        }
        if(cnt != 3){   // not proper parameter
            flog << "100\n";
            
            continue;
        }
        else{
            //flog << newNode->GetName() << newNode->GetAge() << newNode->GetId() << '\n';
            ds_queue->PUSH(newNode);    // push queue
            flog << temp << '\n';
            
        }
    }

    flog << "=======================\n";


    fdata.close();
    flog.close();


    return true;
}

bool Manager::ADD(string v[])
{
    int size = 0;
    for(int i=0;i<10;i++)
        if(v[i] != "")
            size++;

    if(size != 4)   // not proper parameters
        return false;

    char* name = new char[v[1].size()+1];
    copy(v[1].begin(), v[1].end(), name);
    name[v[1].size()] = '\0';

    int age = stoi(v[2]);

    char* id = new char[v[3].size()+1];
    copy(v[3].begin(), v[3].end(), id);
    id[v[3].size()] = '\0';
    // make new queue node
    AccountQueueNode* node = new AccountQueueNode;
    node->SetName(name);
    node->SetAge(age);
    node->SetId(id);

    ds_queue->PUSH(node);   // push queue

    flog.open("log.txt", ios::app);
    flog << "======== ADD ========\n";
    flog << name << '/' << age <<'/' << id << '\n';
    flog << "=====================\n";
    flog.close();


    return true;
}

bool Manager::QPOP(string v[])
{
    int size = 0;
    for(int i=0;i<10;i++)
        if(v[i] != "")
            size++;
    // not proper parameter num
    if(size == 1 || size > 2)
        return false;
    // if queue is empty -> false
    if(ds_queue->SIZE() < stoi(v[1]))
        return false;
        
    AccountBSTNode* bstNode;

    for(int i=0;i<stoi(v[1]);i++){
        AccountQueueNode* pop = ds_queue->POP();
        //cout << pop->GetName() << '\n';

        bool check = false;
        UserListNode* cur = ds_list->GetRoot();
        while(cur!=nullptr){
            if(strcmp(cur->GetName(), pop->GetName()) == 0){
                if(cur->GetAccNum() >= 3){
                    check = true;
                }
            }
            cur = cur->GetNext();
        }
        if(ds_bst->Search_Id(pop->GetId()) || check){   // if overraped id || has 3 account
            flog.open("log.txt", ios::app);
            flog << "301\n";
            flog.close();
            continue;
        }
        
        bstNode = ds_list->Insert(pop, ds_bst);
        // insert list
    }
    
    if(bstNode == nullptr){
        // Print error 301
    }
    
    
    return true;
}

bool Manager::SEARCH(string v[])
{
    int size = 0;   // get parameter size
    for(int i=0;i<10;i++)
        if(v[i] != "")
            size++;

    if(size != 3)
        return false;

    if(v[1] == "user"){ // user mode
        char* str = new char[v[2].size()+1];
        copy(v[2].begin(), v[2].end(), str);
        str[v[2].size()] = '\0';
        if(!ds_list->Search(str))   // not exist
            return false;
        else{
            UserListNode* cur = ds_list->GetRoot();
            while(cur != nullptr){
                if(strcmp(cur->GetName(), str) == 0){
                    break;  // found!!
                }
                else
                    cur = cur->GetNext();
            }
            flog.open("log.txt", ios::app);
            flog << "======== SEARCH ========\n";
            flog << "User\n";
            flog << cur->GetName() << '/' << cur->GetAge() << '\n';
            flog.close();
            cur->Print_Accounts();
            flog.open("log.txt", ios::app);
            flog << "========================\n";
            flog.close();

            return true;
        }
    }
    else if(v[1] == "id"){  // id mode
        char* str = new char[v[2].size()+1];
        copy(v[2].begin(), v[2].end(), str);
        str[v[2].size()] = '\0';
        if(!ds_bst->Search_Id(str)) // if not exist
            return false;
        else{
            AccountBSTNode* cur = ds_bst->GetRoot();
            while(cur != nullptr){
                if(strcmp(cur->GetId(), str) == 0){
                    // Find!
                    flog.open("log.txt", ios::app);
                    flog << "======== SEARCH ========\n";
                    flog << "ID\n";
                    flog << cur->GetId() << '/' << cur->GetName() << '\n';
                    flog << "========================\n";
                    flog.close();
                    break;
                }
                else if(strcmp(cur->GetId(), str) < 0)
                    cur = cur->GetRight();
                else
                    cur = cur->GetLeft();
            }

            return true;
        }
    }
    else
        return false;
}

bool Manager::PRINT(string v[])
{
    int size = 0;
    for(int i=0;i<10;i++)
        if(v[i] != "")
            size++;

    if(size == 1)
        return false;

    if(v[1] == "L" && size == 2)    // Print list
        return ds_list->Print_L(ds_list->GetRoot());

    else if(v[1] == "B" && size == 3){  // print BST
        if(ds_bst->GetRoot() == nullptr){
            cout << "Root is null\n";
            return false;

        }
    
        if(v[2] == "PRE"){      // preorder
            flog.open("log.txt", ios::app);
            flog << "======== PRINT ========\n";
            flog << "BST PRE\n";
            flog.close();
            ds_bst->Print_PRE(ds_bst->GetRoot());
            flog.open("log.txt", ios::app);
            flog << "=======================\n";
            flog.close();
            return true;
        }
        else if(v[2] == "IN"){  // inorder
            flog.open("log.txt", ios::app);
            flog << "======== PRINT ========\n";
            flog << "BST IN\n";
            flog.close();
            ds_bst->Print_IN(ds_bst->GetRoot());
            flog.open("log.txt", ios::app);
            flog << "=======================\n";
            flog.close();
            return true;
        }
        else if(v[2] == "POST"){    // postorder
            flog.open("log.txt", ios::app);
            flog << "======== PRINT ========\n";
            flog << "BST POST\n";
            flog.close();
            ds_bst->Print_POST(ds_bst->GetRoot());
            flog.open("log.txt", ios::app);
            flog << "=======================\n";
            flog.close();
            return true;
        }
        else if(v[2] == "LEVEL"){   // level order
            flog.open("log.txt", ios::app);
            flog << "======== PRINT ========\n";
            flog << "BST LEVEL\n";
            flog.close();
            ds_bst->Print_LEVEL();
            flog.open("log.txt", ios::app);
            flog << "=======================\n";
            flog.close();
            return true;
        }
        return false;

    }
    else if(v[1] == "H" && size == 2){  // print heap
        ds_heap->Print();
        return true;
    }

    return false;
}

bool Manager::DELETE(string v[])
{
    int size = 0;       // get parametr size
    for(int i=0;i<10;i++)
        if(v[i] != "")
            size++;

    if(size == 1 || size > 2)
        return false;
    char* str = new char[v[1].size()+1];
    copy(v[1].begin(), v[1].end(), str);
    str[v[1].size()] = '\0';

    return (ds_list->Delete_Account(str) && ds_bst->Delete(ds_bst->GetRoot(), str));

    return true;
}

bool Manager::HLOAD()
{
    delete ds_heap;         // delete heap
    ds_heap = new UserHeap; // create new heap

    if(ds_list->GetRoot() == nullptr)
        return false;

    UserListNode* cur = ds_list->GetRoot();
    while(cur!=nullptr){    // insert all list node
        ds_heap->Insert(cur->GetAge());
        cur = cur->GetNext();
    }

    return true;
}

bool Manager::EXIT()
{
    delete ds_queue;
    delete ds_list;
    delete ds_bst;
    delete ds_heap;

    return true;
}

void Manager::PrintErrorCode(int num)
{
    flog.open("log.txt", ios::app);
    flog << "========== ERROR ==========" << endl;
    flog << num << endl;
    flog << "===========================" << endl << endl;
    flog.close();
}

void Manager::PrintSuccess(char* act)
{
    flog.open("log.txt", ios::app);
    flog << "========== " << act << " ==========" << endl;
    flog << "Success" << endl;
    flog << "============================" << endl << endl;
    flog.close();
}