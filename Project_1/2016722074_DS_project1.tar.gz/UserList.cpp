#include "UserList.h"
#include <iostream>

UserList::UserList()
{
    Root = nullptr;     // initialize
    tail = nullptr;
}

UserList::~UserList()
{
    if(Root != nullptr){    // delete all list node
        UserListNode* cur = Root;
        while(cur->GetNext()!=nullptr){
            Root = Root->GetNext();
            delete cur;
            cur = Root;
        }
    }
}

UserListNode* UserList::GetRoot()
{
   return Root;
}

AccountBSTNode* UserList::Insert(AccountQueueNode* node, AccountBST* bst)
{
    AccountBSTNode* newAccNode = new AccountBSTNode;    // make new bst node
    newAccNode->SetId(node->GetId());
    newAccNode->SetName(node->GetName());

    UserListNode* newLNode = new UserListNode;          // make new list node
    newLNode->SetName(node->GetName());
    newLNode->SetAge(node->GetAge());
    newLNode->InsertAccount(newAccNode);

    

    if(Root == nullptr){        // if empty
        
        newLNode->SetNext(nullptr);
        
        Root = newLNode;
        tail = newLNode;
    }
    else{                       // not empty
        if(Search(node->GetName())){    // has node same name
            UserListNode* cur = Root;
            while(cur!=nullptr){
                if(strcmp(cur->GetName(), node->GetName()) == 0){
                    
                    cur->InsertAccount(newAccNode);
                    break;
                }
                else
                    cur = cur->GetNext();
            }
            delete newLNode;
            bst->Insert(newAccNode);

            return newAccNode;
        }
        else{   // new list node
            tail->SetNext(newLNode);
            tail = tail->GetNext();
        }

    }
    bst->Insert(newAccNode);
    
    return newAccNode;
}

bool UserList::Search(char* name)
{
    UserListNode* cur = Root;
    while(cur != nullptr){
        if(strcmp(cur->GetName(), name) == 0){  
            return true;    // found!
        }
        else
            cur = cur->GetNext();   // go next
    }
    return false;
}

bool UserList::Delete_Account(char* id)
{   
    UserListNode* prev = Root;
    UserListNode* cur = Root;
    if(cur == nullptr)
        return false;
    bool check = false;
    while(cur!=nullptr){
        if(check == true)
            break;
        AccountBSTNode* temp = cur->GetpHead();
        for(int i=0;i<cur->GetAccNum();i++){
            if(strcmp(temp->GetId(),id) == 0){
                check = true;
                break;   
            }
            temp = temp->GetNext();
        }
        if(check == true)
            break;
        prev = cur;
        cur = cur->GetNext();
    }
    if(check == false){
        //cout << "Not Found!\n";
        return false;
    }

    if(cur->GetAccNum() > 1){
        cur->Delete_Account(id);
        return true;
    }
    else if(Root == tail){      // has 1 node
        cur->Delete_Account(id);
        delete cur;
        return true;
    }
    else if(cur == Root){       // delete first node
        cur = cur->GetNext();
        Root = cur;
        prev->Delete_Account(id);
        delete prev;
        return true;
    }
    else if(cur == tail){       // delete last node
        tail = prev;
        cur->Delete_Account(id);
        delete cur;
        return true;
    }
    else{
        prev->SetNext(cur->GetNext());
        cur->Delete_Account(id);
        delete cur;
        return true;
    }
    return false;
}

bool UserList::Print_L(UserListNode* node)
{
    if(Root == nullptr)
        return false;
        

    UserListNode* cur = Root;
    ofstream flog;
    flog.open("log.txt", ios::app);

    flog << "======== PRINT ========\n";
    flog << "LIST\n";
    while(cur != nullptr){      // traverse all list node
        flog << cur->GetName() << '/' << cur->GetAge() << '/' << cur->GetAccNum() << '\n';
        cur = cur->GetNext();
    }
    flog << "=======================\n";

    flog.close();

    return true;
}
