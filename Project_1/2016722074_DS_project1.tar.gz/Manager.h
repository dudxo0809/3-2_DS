#pragma once
#include "AccountBST.h"
#include "AccountQueue.h"
#include "UserHeap.h"
#include "UserList.h"
#include <string>

class Manager
{
private:
	AccountQueue* ds_queue;
	AccountBST* ds_bst;
	UserHeap* ds_heap;
	UserList* ds_list;
	ifstream fin;
	ofstream flog;

	

	bool QLOAD_Check = false;

public:
	Manager();
	~Manager();

	void run(const char* command);
	bool QLOAD();
	bool ADD(string v[]);
	bool QPOP(string v[]);
	bool SEARCH(string v[]);
	bool PRINT(string v[]);
	bool DELETE(string v[]);
	bool HLOAD();
	bool EXIT();

	void PrintErrorCode(int num);
	void PrintSuccess(char* act);
};
