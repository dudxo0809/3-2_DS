#include "UserListNode.h"

UserListNode::UserListNode()
{
    Name = new char[50];
    Age = -1;
    AccNum = 0;
    pNext = nullptr;
    pHead = nullptr;
}

UserListNode::~UserListNode()
{
    delete[] Name;
}

char* UserListNode::GetName()
{
    return Name;
}

int UserListNode::GetAge()
{
    return Age;
}

UserListNode* UserListNode::GetNext()
{
    return pNext;
}

void UserListNode::SetName(char* name)
{
    memcpy(Name, name, sizeof(char) * 50);
}

void UserListNode::SetAge(int age)
{
    Age = age;
}

void UserListNode::SetNext(UserListNode* node)
{
    pNext = node;
}

AccountBSTNode* UserListNode::InsertAccount(AccountBSTNode* node)
{
    if(AccNum == 0){
        pHead = node;
    }
    else{
        AccountBSTNode* cur = pHead;
        while(cur->GetNext() != nullptr){
            cur = cur->GetNext();
        }
        cur->SetNext(node);
    }
    AccNum++;
}

void UserListNode::Print_Accounts()
{
    std::ofstream flog;
    flog.open("log.txt", std::ios::app);
    AccountBSTNode* cur =  GetpHead();
    while(cur!=nullptr){
        flog << cur->GetId() << '\n';
        cur = cur->GetNext();
    }

    flog.close();
}

void UserListNode::Delete_Account(char* id)
{
    if(AccNum == 1){
        AccNum--;
        pHead = nullptr;
    }
    else{
        AccountBSTNode* cur = pHead;
        AccountBSTNode* prev = nullptr;
        while(cur != nullptr){              // traverse all bst node
            if(strcmp(cur->GetId(), id) == 0){
                if(pHead == cur){
                    pHead = cur->GetNext();
                    cur->SetNext(nullptr);
                    AccNum--;
                    return;
                }
                else if(cur->GetNext() == nullptr){
                    prev->SetNext(nullptr);
                    AccNum--;
                    return;
                }
                else{
                    prev->SetNext(cur->GetNext());
                    cur->SetNext(nullptr);
                    AccNum--;
                    return;
                }
            }
            else{
                prev = cur;
                cur = cur->GetNext();
            }
        }
    }
}
