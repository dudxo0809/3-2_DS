#include "AccountBST.h"


AccountBST::AccountBST()
{
    Root = nullptr;
}

AccountBST::~AccountBST()
{

}

AccountBSTNode* AccountBST::GetRoot()
{
    return Root;
}

bool AccountBST::Insert(AccountBSTNode* node)
{
    AccountBSTNode* parent = nullptr;   // point cur->parent
    AccountBSTNode* cur = Root;

    if(Root == nullptr){    // if BST is empty
        Root = node;
        return true;
    }
    if(strcmp(node->GetId(), cur->GetId()) == 0){   // not match
        return false;
    }
    else{
        while(cur != nullptr){
            parent = cur;
            if(strcmp(node->GetId(), cur->GetId()) < 0) // go to left
                cur = cur->GetLeft();
            else
                cur = cur->GetRight();  // go to right
        }
        if(strcmp(node->GetId(), parent->GetId()) < 0)  // Set node
            parent->SetLeft(node);
        else
            parent->SetRight(node);

        return true;
    }
}

bool AccountBST::Search_Id(char* id)
{
    AccountBSTNode* temp = Root;    // start root

    while(temp != nullptr){
        
        if(strcmp(id, temp->GetId()) == 0)  // found
            return true;
        else if(strcmp(id, temp->GetId()) < 0)
            temp = temp->GetLeft(); // go left
        else
            temp = temp->GetRight(); // go right
    }

    return false;   // not found
}

AccountBSTNode* AccountBST::Delete(AccountBSTNode* root, char* id)
{
    if(root == nullptr) // leaf->child
        return root;
    if(strcmp(id, root->GetId()) < 0)   // go left
        root->SetLeft(Delete(root->GetLeft(), id));
    else if(strcmp(id, root->GetId()) > 0)  // go right
        root->SetRight(Delete(root->GetRight(), id));
    else{   // find!
        if(root->GetLeft() == nullptr){ // has 1 child
            AccountBSTNode* temp = root->GetRight();
            delete root;
            return temp;
        }   // has no child
        else if(root->GetRight() == nullptr){
            AccountBSTNode* temp = root->GetLeft();
            delete root;
            return temp;
        }   // has 2 child
        AccountBSTNode* temp = GetMinNode(root->GetRight());
        root->SetId(temp->GetId());
        root->SetName(temp->GetName());
        root->SetRight(Delete(root->GetRight(), temp->GetId()));
    }
    return root;
}

void AccountBST::Print_PRE(AccountBSTNode* node)
{
    if(node == nullptr)
        return;
    // root
    flog.open("log.txt", ios::app);
    flog << node->GetId() << '/' << node->GetName() << "\n";
    flog.close();

    Print_PRE(node->GetLeft());     // left sub tree
    Print_PRE(node->GetRight());    // right sub tree 
    
    return;
}

void AccountBST::Print_IN(AccountBSTNode* node)
{
    if(node == nullptr)
        return;

    Print_IN(node->GetLeft());      // left sub tree
    // root
    flog.open("log.txt", ios::app);
    flog << node->GetId() << '/' << node->GetName() << '\n';
    flog.close();

    Print_IN(node->GetRight());     // right sub tree
    return;
}

void AccountBST::Print_POST(AccountBSTNode* node)
{
    if(node == nullptr)
        return;

    Print_POST(node->GetLeft());    // left sub tree
    Print_POST(node->GetRight());   // right sub tree
    // root
    flog.open("log.txt", ios::app);
    flog << node->GetId() << '/' << node->GetName() << "\n";
    
    flog.close();  
}

void AccountBST::Print_LEVEL()
{
    queue<AccountBSTNode*> q;
    q.push(Root);       // push root

    while(!q.empty()){  
        
        flog.open("log.txt", ios::app);
        flog << q.front()->GetId() << '/' << q.front()->GetName() << '\n';
        flog.close();

        AccountBSTNode* left = q.front()->GetLeft();
        AccountBSTNode* right = q.front()->GetRight();
        q.pop();    // current node end
        if(left != nullptr) // next level
            q.push(left);
        if(right != nullptr)
            q.push(right);
    }
}