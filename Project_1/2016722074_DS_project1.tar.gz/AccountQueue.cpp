#include "AccountQueue.h"


#include "AccountQueue.h"

AccountQueue::AccountQueue()
{
    queue_size = 0;
    Front = nullptr;
}

AccountQueue::~AccountQueue()
{
    int size = queue_size;
    AccountQueueNode* temp;

    for(int i=0;i<size;i++){
        temp = Front;
        Front = Front->GetNext();
        delete temp;
    }
}

AccountQueueNode* AccountQueue::POP()
{
    if(EMPTY()){
        return nullptr;
    }
    else{
        queue_size--;
        AccountQueueNode* temp = Front;
        Front = Front->GetNext();
        temp->SetNext(nullptr);
        return temp;
    }
}
bool AccountQueue::PUSH(AccountQueueNode* node)
{
    AccountQueueNode* newNode = new AccountQueueNode;
    newNode->SetName(node->GetName());
    newNode->SetAge(node->GetAge());
    newNode->SetId(node->GetId());
    // make new queue node
    
    
    if(EMPTY()){    // empty queue
        Front = newNode;

    }
    else{   // go to last node
        AccountQueueNode* cur = Front;
        if(cur->GetNext() == nullptr)
            cur->SetNext(newNode);
        else{
            while(1){
                if(cur->GetNext() == nullptr){
                    cur->SetNext(newNode);
                    break;
                }
                cur = cur->GetNext();
            }
        }
    }
    
    queue_size++;

    return true;
}

bool AccountQueue::EMPTY()
{   // if empty ? return  true : false;
    if(queue_size == 0){
        return true;
    }
    else{
        return false;
    }
}

int AccountQueue::SIZE()
{   // return size
    return queue_size;
}

// print queue until last node
void AccountQueue::PRINT()
{
    int size = queue_size;
    AccountQueueNode* cur = Front;

    fstream flog;
    flog.open("log.txt", ios::app);
    for(int i=0;i<size;i++){
         flog << cur->GetName() << '/' << cur->GetAge() << '/' << cur->GetId() << '\n';
         cur = cur->GetNext();
    }
    flog << "!!!!!!!!!!1\n";
    flog.close();
}