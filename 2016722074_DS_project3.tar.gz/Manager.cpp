#include "Manager.h"
#include <cstring>

Manager::~Manager()
{
    if (fout.is_open())
        fout.close();

    

    //if (ferr.is_open())
        //ferr.close();
}

void Manager::Run(const char* filepath)
{
    fout.open(RESULT_LOG_PATH);
    //ferr.open(ERROR_LOG_PATH);
    fcmd.open(filepath);

    if(!fcmd){      // has no cmd file
        //error 101
        PrintError(CommandFileNotExist);
        fout.close();
        return;
    }

    while(!fcmd.eof()){     // read all cmd file
        string cmd;
        fcmd >> cmd;
        
        if(cmd == "LOAD"){  // LOAD
            string cmdfile;
            fcmd >> cmdfile;
            Result result = Load(cmdfile.c_str());      // Do Load func
            if(result == Success){
                fout << "===== LOAD =====" << endl;
                fout << "Success" << endl;
                fout << "================" << endl;
                PrintError(result);                     // error 0
            }
            else if(result == LoadFileNotExist){        // has no map file
                PrintError(result);
                break;
            }
        }
        else if(cmd == "LOADREPORT"){                   // Load report file
            getline(fcmd, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
            v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
			
            string report_txt = v[2];       // reportdata.txt

            //cout << cnt << endl;

            frep.open(report_txt);
            if(!frep){
                PrintError(FaildtoUpdatePath);      // has no file
                continue;
            }
            else{
                int idx = 0;
                while(!frep.eof()){                 // read all report file
            
                    string str;
                    getline(frep, str);
                    report.push_back(str);          // Save in vector
                }

                fout << "\n===== LOADREPORT =====" << endl;
                fout << "Success" << endl;
                fout << "======================" << endl;
                fout << "\n======================" << endl;
                fout << "Error code: 0" << endl;
                fout << "======================" << endl;
            }

        }
        else if(cmd == "PRINT"){                    // Print
            if(Print() == GraphNotExist)
                PrintError(GraphNotExist);
        }
        else if(cmd == "BFS"){                      // BFS
            getline(fcmd, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
            v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
            
			if(cnt > 1){                            // extra parameter??
                PrintError(InvalidVertexKey);       // error
                continue;
            }

            Result result = FindPathBfs(0, m_graph.Size() -1);  // 0 to end vertex
            if(result != Success)
                PrintError(result);                 // print error
        }
        else if(cmd == "DIJKSTRA"){                 // Dijkstra
            getline(fcmd, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
            v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
			if(cnt > 1){
                PrintError(InvalidVertexKey);       // unnecesary parameter
                continue;
            }

            Result result = FindShortestPathDijkstraUsingSet(0, m_graph.Size() - 1);
            if(result != Success)
                PrintError(result);
        }
        else if(cmd == "BELLMANFORD"){                 // Bellmanford
            getline(fcmd, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
            v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
			if(cnt > 1){
                PrintError(InvalidVertexKey);           // unnecesary parameter
                continue;
            }

            Result result = FindShortestPathBellmanFord(0, m_graph.Size()-1);
            if(result != Success)
                PrintError(result);
        }
        else if(cmd == "FLOYD"){                    // Floyd
            getline(fcmd, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
            v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
			if(cnt > 1){
                PrintError(InvalidVertexKey);           // unnecesary parameter
                continue;
            }

            Result result = FindShortestPathFloyd();
            if(result != Success)
                PrintError(result);
        }
        else if(cmd == "RABINKARP"){                // Rabinkarp
            
            string cmd;
            getline(fcmd, cmd);
            size_t current = cmd.find(' ');
            string text = cmd.substr(current + 1, string::npos);

            if(text.length() >= 10){
                PrintError(InvalidOptionNumber);
                continue;
            }
            int cnt = 0;
            fout << "\n======RABINKARP======" << endl;
            for(int k=0;k<report.size(); k++){      // loop all report data
                string parent = report[k];
                string pattern = text;
        
                string _parent = parent;
                string _pattern = pattern;
                for(int i=0;i<parent.length();i++)              // No-case sensitive
                    if (65 <= parent[i] && parent[i] <= 90)
                        _parent[i] += 32;
                for(int i=0;i<pattern.length();i++)
                    if (65 <= pattern[i] && pattern[i] <= 90)
                        _pattern[i] += 32;

                int length_parent = _parent.length();
                int length_pattern = _pattern.length();

                int hash_parent = 0;
                int hash_pattern = 0;
                int power = 1;
                // Get Hash!
                for(int i= length_pattern - 1; i >= 0; i--){
                    hash_parent = hash_parent + _parent[i] * power;
                    hash_pattern = hash_pattern + _pattern[i] * power;
                    if(i>0)
                        power = power * 2;
                }
                for(int i=0;i<length_parent - length_pattern + 1; i++){
                    if(i>0)
                        hash_parent = (hash_parent - _parent[i-1] * power) * 2 + _parent[length_pattern - 1 + i];
                    if(hash_parent == hash_pattern){        // if same hash
                        // Catch pattern!!
                        cnt++;
                        // Log 
                        if(cnt == 1)        // print only first time
                            fout << "DUPLICATE TITLE EXISTS" << endl;
                        fout << parent << endl;
                        break;
                    }    
                }
            }
            if(cnt == 0)        // if has no match string
                    fout << "NO DUPLICATE TITLE EXISTS" << endl;
                fout << "===================" << endl;

        }
        else{
            //cout << "cmd :" << cmd << endl;
            PrintError(NonDefinedCommand);
            break;
        }


    }

    fcmd.close();
    fout.close();
    //ferr.close();
    // TODO: implement
}
void Manager::PrintError(Result result)
{
    if(result == CommandFileNotExist){      // Load fail
        fout << "\n";
        fout << "====== SYSTEM ======" << endl;
        fout << "CommandFileNotExist" << result << std::endl;
        fout << "====================" << endl;
    }
    else{
        fout << "\n";
        fout << "================" << endl;
        fout << "Error code: " << result << std::endl;    
        fout << "================" << endl;
    }
}

/// <summary>
/// make a graph
/// </summary>
///
/// <param name="filepath">
/// the filepath to read to make the graph
/// </param>
///
/// <returns>
/// Result::Success if load is successful.
/// Result::LoadFileNotExist if file is not exist.
/// </returns>
Result Manager::Load(const char* filepath)
{
    fmap.open(filepath);
    if(!fmap){
        return LoadFileNotExist;
    }
    else{
        int idx = 0;
        while(!fmap.eof()){
            
            string str;
            getline(fmap, str);
            size_t current = str.find('/');
            string name = str.substr(0, current - 1);
            string vertex = str.substr(current+2, string::npos);    // vertex data include space(' ')

            string v[30];
            size_t prev = 0;
            current = vertex.find(' ');
            int cnt = 0;
            // toknize all data
            while(current != string::npos){
                
                string sub = vertex.substr(prev, current - prev);
                v[cnt] = sub;
                prev = current + 1;
                current = vertex.find(' ', prev);
                cnt++;
            }
            
            v[cnt++] = vertex.substr(prev, current - prev);     // each v has 1 vertex->vertex data

            // Add Egde
            for(int i=0;i<cnt;i++){
                if(v[i] != "0"){
                    m_graph.AddEdge(idx, i, atoi(v[i].c_str()));    // Save data
                }
            }
            
            company.push_back(name);

            idx++;
        }
    }
    return Success;

    fmap.close();
    // TODO: implement
}
/// <summary>
/// print out the graph as matrix form
/// </summary>
///
/// <returns>
/// Result::Success if the printing is successful
/// Result::GraphNotExist if there is no graph
/// </returns>
Result Manager::Print()     // Print all graph data
{
    // TODO: implement
    if(m_graph.Size() == 0) // has no data
        return GraphNotExist;
    else{
        fout << "\n";
        fout << "==== PRINT =====" << endl;
        m_graph.Print(fout);
        fout << "================" << endl;
        return Success;
    }
}
/// <summary>
/// find the path from startVertexKey to endVertexKey with DFS 
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::InvalidAlgorithm if an exception has occurred.
/// Result::Success otherwise.
/// </returns>
Result Manager::FindPathBfs(int startVertexKey, int endVertexKey)
{
    if(m_graph.Size() == 0)
        return GraphNotExist;
    
    int length = 0;
    int isneg = 0;
    vector<int> path;
    path = m_graph.FindPathBfs(startVertexKey, endVertexKey, &length, &isneg);  // get shortest path

    if(isneg == 1){
        fout << "\n===== InvalidAlgorithm =====" << endl;   // has negative edge
    }
    else
        fout << "\n===== BFS =====" << endl;        // no negative edge

    fout << "shortest path: ";              // Print BFS result
    for(auto i : path)
        fout << i << " ";
    fout << endl;

    fout << "path length: " << length << endl;
    
    fout << "Course : ";
    
    for(int i=0;i<path.size();i++)
        fout << company[path[i]] << " ";
    fout << endl;
    fout << "================" << endl;

    if(isneg == 1)
        PrintError(InvalidAlgorithm);   // error 203

    return Success;

    // TODO: implement
}
/// <summary>
/// find the shortest path from startVertexKey to endVertexKey with Dijkstra using std::set
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::InvalidAlgorithm if an exception has occurred.
/// Result::Success otherwise.
/// </returns>
Result Manager::FindShortestPathDijkstraUsingSet(int startVertexKey, int endVertexKey)
{
    if(m_graph.Size() == 0)     // has no data
        return GraphNotExist;
    
    int length = 0;
    int isneg = 0;
    vector<int> path;
    // get shortest path
    path = m_graph.FindShortestPathDijkstraUsingSet(startVertexKey, endVertexKey, &length, &isneg);

    if(isneg == 1){
        fout << "\n===== InvalidAlgorithm =====" << endl;
    }
    else
        fout << "\n===== DIJKSTRA =====" << endl;

    fout << "shortest path: ";      // Log Dijkstra result
    for(auto i : path)
        fout << i << " ";
    fout << endl;

    fout << "path length: " << length << endl;
    
    fout << "Course : ";
    
    for(int i=0;i<path.size();i++)
        fout << company[path[i]] << " ";
    fout << endl;
    fout << "================" << endl;
    if(isneg == 1)
        PrintError(InvalidAlgorithm);   // error 203

    return Success;

    // TODO: implement
}
/// <summary>
/// find the shortest path from startVertexKey to endVertexKey with Bellman-Ford
/// </summary>
///
/// <param name="startVertexKey">
/// the start vertex key
/// </param>
/// <param name="endVertexKey">
/// the end vertex key
/// </param>
///
/// <returns>
/// Result::InvalidVertexKey or Result::GraphNotExist or Result::NegativeCycleDetected if exception has occurred.
/// Result::Success otherwise.
/// </returns>
Result Manager::FindShortestPathBellmanFord(int startVertexKey, int endVertexKey)
{
    if(m_graph.Size() == 0)     // has no data
        return GraphNotExist;

    int length;
    int isneg = 0;
    vector<int> path;
    // get path
    path = m_graph.FindShortestPathBellmanFord(startVertexKey, endVertexKey, &length, &isneg);

    if(path.size() == 0)
        return NegativeCycleDetected;

    fout << "\n===== BELLMANFORD =====" << endl;    // Log bellmanford result
    fout << "shortest path: ";
    for(auto i : path)
        fout << i << " ";
    fout << endl;

    fout << "path length: " << length << endl;
    
    fout << "Course : ";
    
    for(int i=0;i<path.size();i++)
        fout << company[path[i]] << " ";
    fout << endl;
    fout << "================" << endl;
    
    return Success;
    
    // TODO: implement
}

Result Manager::FindShortestPathFloyd(){
    if(m_graph.Size() == 0)
        return GraphNotExist;

    vector<vector<int>> path;
    path = m_graph.FindShortestPathFloyd();     // get matrix
    if(path.size() == 0)
        return NegativeCycleDetected;       // has no data

    fout << "\n===== FLOYD =====" << endl;  // Log result
    for(int i=0;i<path.size();i++){
        for(int j=0;j<path[i].size();j++){
            fout << path[i][j] << " ";
        }
        fout << endl;
    }
    fout << "=================" << endl;

    return Success;
}

Result Manager::RabinKarpCompare(const char* CompareString,const char* ComparedString)  // implement in Run func
{
    // TODO: implement
}
