#include "Graph.h"
#include "Stack.h"
#include "MinHeap.h"
#include <set>
#include <queue>

#define BFS_FIRST_PATH

Graph::Graph()
{
    // TODO: implement
}
Graph::~Graph()
{
    // TODO: implement
}

void Graph::AddVertex(int vertexKey)
{
    Vertex* newVertex = new Vertex(vertexKey);
    Vertex* cur = m_pVHead;

    m_vSize++;
    // if empty
    if (m_pVHead == nullptr) {
        m_pVHead = newVertex;
        return;
    }
    else {  // find position!
        while (cur != nullptr) {
            if (cur->GetNext() == nullptr) {
                cur->SetNext(newVertex);
                return;
            }
            if (cur->GetNext()->GetKey() > vertexKey) {
                newVertex->SetNext(cur->GetNext());
                cur->SetNext(newVertex);
                return;
            }      
            cur = cur->GetNext();
        }
    }
}

void Graph::AddEdge(int startVertexKey, int endVertexKey, int weight)
{
    // if has no vertex
    if (FindVertex(startVertexKey) == nullptr) {
        AddVertex(startVertexKey);
    }

    Vertex* cur_v = m_pVHead;
    while (cur_v != nullptr) {  // find position
        if (cur_v->GetKey() == startVertexKey) {
            cur_v->AddEdge(endVertexKey, weight);
            return;
        }
        cur_v = cur_v->GetNext();
    }
}

Vertex* Graph::FindVertex(int key)
{
    Vertex* cur = m_pVHead;
    while (cur != nullptr) {
        if (cur->GetKey() == key)
            return cur;
        cur = cur->GetNext();
    }
    return nullptr;     // not found
}

void Graph::Clear()     // free all memory
{
    Vertex* cur = m_pVHead;
    while (cur != nullptr) {    // traverse all vertex
        cur->Clear();
        cur = cur->GetNext();
    }
}

void Graph::Print(std::ofstream& fout)
{
    Vertex* cur_v = m_pVHead;
    while (cur_v != nullptr) {

        Edge* e = cur_v->GetHeadOfEdge();
        for (int i = 0; i < m_vSize; i++) {
            if (e == nullptr)       // if has no more edge
                fout << "0 ";
            else if (e->GetKey() != i)
                fout << "0 ";
            else {                  // print weight
                fout << e->GetWeight() << " ";
                e = e->GetNext();
            }
        }
        fout << endl;
        cur_v = cur_v->GetNext();
    }

}

bool Graph::IsNegativeEdge()
{
    Vertex* v = m_pVHead;
    Edge* e;

    while (v != nullptr) {      // traverse all graph
        e = v->GetHeadOfEdge();
        while (e != nullptr) {      // traverse all vertex
            if (e->GetWeight() <= 0)
                return true;
            e = e->GetNext();
        }
        v = v->GetNext();
    }

    return false;
}

std::vector<int> Graph::FindPathBfs(int startVertexKey, int endVertexKey, int* length, int* isneg)
{
    vector<bool> visit(m_vSize, false);
    vector<int> dist(m_vSize, 0);      // distance
    vector<int> trace(m_vSize);     // path
    queue<int> q;


    q.push(startVertexKey);
    visit[startVertexKey] = true;   // start vertex

    while (!q.empty()) {            // if empty queue
        int front = q.front();
        q.pop();
        
        Vertex* v_cur = m_pVHead;
        while (v_cur != nullptr) {
            if (v_cur->GetKey() == front)
                break;
            v_cur = v_cur->GetNext();
        }
        Edge* e_cur = v_cur->GetHeadOfEdge();
        while (e_cur != nullptr) {
            if (visit[e_cur->GetKey()] == false) {
                if (e_cur->GetWeight() < 0) {
                    // error 203
                    // negative weight!!
                    *isneg = 1;

                    e_cur = e_cur->GetNext();
                    continue;
                }
                if (e_cur->GetKey() == endVertexKey) {
                    // Finish!!

                }
                visit[e_cur->GetKey()] = true;
                q.push(e_cur->GetKey());

                trace[e_cur->GetKey()] = v_cur->GetKey();
                dist[e_cur->GetKey()] = dist[v_cur->GetKey()] + e_cur->GetWeight();
            }
            e_cur = e_cur->GetNext();
        }

    }
    // out length
    *length = dist[endVertexKey];

    // trace shortet path
    vector<int> ret, _ret;
    int temp = endVertexKey;
    while (temp) {
        ret.push_back(temp);
        temp = trace[temp];
    }
    _ret.push_back(startVertexKey);
    for (int i = ret.size() - 1; i >= 0; i--)
        _ret.push_back(ret[i]);

    return _ret;
}

std::vector<int> Graph::FindShortestPathDijkstraUsingSet(int startVertexKey, int endVertexKey, int* length, int* isneg)
{
    set<pair<int, int>> s;
    vector<int> d(m_vSize, IN_FINITY);
    vector<int> trace(m_vSize);

    s.insert(make_pair(startVertexKey, 0));
    d[startVertexKey] = 0;

    while (!s.empty()) {
      
        int current = s.begin()->first;
        int distance = s.begin()->second;
        s.erase(s.begin());

        if (d[current] < distance) continue;

        // Find Vertex has 'current' key
        // Assume vertex has finding data
        Vertex* v_cur = m_pVHead;
        while (v_cur != nullptr) {

            if (v_cur->GetKey() == current)
                break;
            else
                v_cur = v_cur->GetNext();
        }
        if (v_cur == nullptr) {
            // error 202!!!
            //
            
        }

        // current vertex loop edge
        Edge* e_cur = v_cur->GetHeadOfEdge();
        while (e_cur != nullptr) {

            int next = e_cur->GetKey();
            int nextDistance = e_cur->GetWeight();

            if (e_cur->GetWeight() < 0) {
                // Print error 203
                // negative weight
                // Ignore neg weight edge
                *isneg = 1;

                e_cur = e_cur->GetNext();
                continue;
            }

            if (d[next] > d[current] + nextDistance) {

                d[next] = d[current] + nextDistance;
                s.insert(make_pair(next, nextDistance));

                // if shortest path change
                trace[next] = current;
            }

            e_cur = e_cur->GetNext();
        }

    }
    // out length
    *length = d[endVertexKey];

    // trace shortet path
    vector<int> ret, _ret;
    int temp = endVertexKey;
    while (temp) {
        ret.push_back(temp);
        temp = trace[temp];
    }
    _ret.push_back(startVertexKey);
    for (int i = ret.size() - 1; i >= 0; i--)
        _ret.push_back(ret[i]);

    return _ret;
}

std::vector<int> Graph::FindShortestPathBellmanFord(int startVertexKey, int endVertexKey, int* length, int* isneg)
{
    vector<int> d(m_vSize, IN_FINITY);
    vector<int> trace(m_vSize);
    d[startVertexKey] = 0;

    for (int i = 0; i < m_vSize; i++) {     // To get shortest distance
        Vertex* v_cur = m_pVHead;
        while (v_cur != nullptr) {
            Edge* e_cur = v_cur->GetHeadOfEdge();
            while (e_cur != nullptr) {

                int from = v_cur->GetKey();
                int to = e_cur->GetKey();
                int cost = e_cur->GetWeight();
                if(cost < 0)
                    *isneg = 1;

                if (d[from] == IN_FINITY)
                    continue;
                if (d[to] > d[from] + cost) {   // change shortest distance
                    d[to] = d[from] + cost;
                    
                    trace[to] = from;           // for pathfinding
                }

                e_cur = e_cur->GetNext();
            }


            v_cur = v_cur->GetNext();
        }
    }
            // Finding egative cycle
    Vertex* v_cur = m_pVHead;
    while (v_cur != nullptr) {
        Edge* e_cur = v_cur->GetHeadOfEdge();
        while (e_cur != nullptr) {

            int from = v_cur->GetKey();
            int to = e_cur->GetKey();
            int cost = e_cur->GetWeight();

            if (d[from] == IN_FINITY)
                continue;

            if (d[to] > d[from] + cost) {
                // error 204
                // negative cycle
                vector<int> empty_v;
                return empty_v;
            }

            e_cur = e_cur->GetNext();
        }


        v_cur = v_cur->GetNext();
    }

    // out length
    *length = d[endVertexKey];

    // trace shortet path
    vector<int> ret, _ret;
    int temp = endVertexKey;
    while (temp) {
        ret.push_back(temp);
        temp = trace[temp];
    }
    _ret.push_back(startVertexKey);
    for (int i = ret.size() - 1; i >= 0; i--)
        _ret.push_back(ret[i]);

    return _ret;
}

std::vector<vector<int>> Graph::FindShortestPathFloyd()
{
    vector<vector<int>> d;          // all graph map
    Vertex* v_cur = m_pVHead;
    while (v_cur != nullptr) {      // make matrix
        Edge* e_cur = v_cur->GetHeadOfEdge();
        vector<int> temp;
        for (int i = 0; i < m_vSize; i++) {
            if (i == v_cur->GetKey())
                temp.push_back(0);
            else if (e_cur == nullptr)
                temp.push_back(IN_FINITY);      // has no edge
            else if (e_cur->GetKey() == i) {
                temp.push_back(e_cur->GetWeight());
                e_cur = e_cur->GetNext();
            }
            else
                temp.push_back(IN_FINITY);
            
        }
        d.push_back(temp);

        v_cur = v_cur->GetNext();
    }

    for (int k = 0; k < m_vSize; k++) {     // Floyd algorithm
        for (int i = 0; i < m_vSize; i++) {
            for (int j = 0; j < m_vSize; j++) {
                int temp = d[i][k] + d[k][j];
                if (temp < d[i][j])         // change shortest path
                    d[i][j] = temp;
            }
        }
    }

    for (int i = 0; i < m_vSize; i++) {
        if (d[i][i] < 0) {
            // error 204
            // negative cycle
            vector<vector<int>> empty_v;
            return empty_v;
        }
    }


    return d;
}
