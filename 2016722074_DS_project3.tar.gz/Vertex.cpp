#include "Vertex.h"

void Vertex::AddEdge(int edgeKey, int weight){

	Edge* newEdge = new Edge(edgeKey, weight);
	Edge* cur = m_pEHead;

	if (cur == nullptr)		// has no edge
		m_pEHead = newEdge;
	else {

		while (cur != nullptr) {	// find position

			if (cur->GetNext() == nullptr) {

				cur->SetNext(newEdge);
				return;
			}
			if (cur->GetNext()->GetKey() > edgeKey) {
				newEdge->SetNext(cur->GetNext());
				cur->SetNext(newEdge);
				return;
			}
			cur = cur->GetNext();	// find next pos
		}
	}
}

Edge* Vertex::GetHeadOfEdge() const{

	return m_pEHead;
}

void Vertex::Clear() {

	Edge* cur = m_pEHead;
	while (cur != nullptr) {	// deallocate
		delete cur;
		cur = cur->GetNext();
	}
}
