#include "BpTree.h"
bool BpTree::Insert(VaccinationData* newData) {

	string newname = newData->GetUserName();
	BpTreeDataNode* newNode = new BpTreeDataNode;
	newNode->insertDataMap(newname, newData);
	

	// empty Bptree
	if (root == nullptr) {
		
		root = newNode;
		return true;
	}
	
	if(IsInoculationComplete(newData)){
		return false;
		// get error 300
	}

	VaccinationData* temp = FindVaccineData(newData->GetUserName());
	if(temp != nullptr){
		// if already has node
		temp->SetTimes(temp->GetTimes() + 1);
		return true;
	}
	// if new node insert

	

	// has no index node
	if (root->getMostLeftChild() == nullptr) {
		
		root->getDataMap()->insert(make_pair(newname, newData));
		if (root->getDataMap()->size() == 3)
			splitDataNode(root);
		
		return true;
	}
	
	BpTreeNode* cur;
	cur = root;

	// find insert point : cur
	// if cur->getindexmap size == 0 : means cur point at data node
	while (cur->getMostLeftChild() != nullptr) {

		int cnt = 0;
		map<string, BpTreeNode*>::iterator iter = cur->getIndexMap()->begin();
		map<string, BpTreeNode*>::iterator iter1 = iter;
		map<string, BpTreeNode*>::iterator iter2 = ++iter;

		// index node has 1 map node or 2 map node
		if (cur->getIndexMap()->size() == 1) {
			if (newname < iter1->first) {
				cur = cur->getMostLeftChild();
			}
			else {
				cur = iter1->second;
			}
		}
		else if (cur->getIndexMap()->size() == 2) {
			if (newname < iter1->first) {
				cur = cur->getMostLeftChild();
			}
			else if (iter1->first < newname && newname < iter2->first) {
				cur = iter1->second;
			}
			else if (iter2->first < newname) {
				cur = iter2->second;
			}
		}

	}

	// insert node
	cur->getDataMap()->insert(make_pair(newname, newData));
	if (cur->getDataMap()->size() == 3) {
		splitDataNode(cur);
	}

	
	return true;
}

// Not using this func
BpTreeNode* BpTree::searchDataNode(string n) {
	if (root == NULL) {
		return nullptr;
	}
	BpTreeNode* cur = root;
	
}
void BpTree::splitDataNode(BpTreeNode* pDataNode) {
	// make new index node
	// make new data node form old data node
	// connect all together

	BpTreeIndexNode* newIndexNode = new BpTreeIndexNode;
	BpTreeDataNode* newDataNode = new BpTreeDataNode;

	map<string, VaccinationData*>::iterator iter = pDataNode->getDataMap()->begin();
	string prevname = iter->first;
	
	// new data node
	newDataNode->insertDataMap(iter->first, iter->second);
	iter++;		// iter : second data node in map
	string midname = iter->first;
	pDataNode->getDataMap()->erase(prevname);

	if (pDataNode->getParent() == nullptr) {
		// new index node
		newIndexNode->insertIndexMap(midname, pDataNode);
		newIndexNode->setMostLeftChild(newDataNode);

		newDataNode->setParent(newIndexNode);
		pDataNode->setParent(newIndexNode);

		newDataNode->setNext(pDataNode);
		pDataNode->setPrev(newDataNode);

		root = newIndexNode;
	}
	else {
		pDataNode->getPrev()->setNext(newDataNode);
		newDataNode->setPrev(pDataNode->getPrev());
		newDataNode->setNext(pDataNode);
		pDataNode->setPrev(newDataNode);

		pDataNode->getParent()->getIndexMap()->insert(make_pair(midname, pDataNode));
		//pDataNode->setMostLeftChild(newDataNode);

		newDataNode->setParent(newIndexNode);
		pDataNode->setParent(newIndexNode);

	}
	

	// pDataNode : right data node
	// newDataNode : left data node
	
}

void BpTree::splitIndexNode(BpTreeNode* pIndexNode) {

	// make new index node
	
	BpTreeIndexNode* newIndexNode = new BpTreeIndexNode;
	BpTreeIndexNode* left = new BpTreeIndexNode;
	BpTreeIndexNode* right = new BpTreeIndexNode;

	map<string, BpTreeNode*>::iterator iter = pIndexNode->getIndexMap()->begin();
	map<string, BpTreeNode*>::iterator up_iter;
	
	// current iter : fisrt node in index map
	left->insertIndexMap(iter->first, iter->second);
	pIndexNode->getMostLeftChild()->setParent(left);
	iter->second->setParent(left);
	left->setMostLeftChild(pIndexNode->getMostLeftChild());

	iter++;
	up_iter = iter;	// up_iter : split new index node
	iter++;			// iter : last index node

	// make new right index node
	right->insertIndexMap(iter->first, iter->second);
	up_iter->second->setParent(right);
	iter->second->setParent(right);
	right->setMostLeftChild(up_iter->second);


	if (pIndexNode->getParent() == nullptr) {
		// make top index node
		newIndexNode->insertIndexMap(up_iter->first, right);
		newIndexNode->setMostLeftChild(left);
		left->setParent(newIndexNode);
		right->setParent(newIndexNode);

		root = newIndexNode;
	}
	else {
		pIndexNode->getParent()->getIndexMap()->insert(make_pair(up_iter->first, up_iter->second));
		newIndexNode->setMostLeftChild(left);
		left->setParent(newIndexNode);
		right->setParent(newIndexNode);
	}
	

}

// Not using this 3 func
bool BpTree::exceedDataNode(BpTreeNode* pDataNode) {
	return true;
}

bool BpTree::exceedIndexNode(BpTreeNode* pIndexNode) {
	return true;
}

void BpTree::SearchRange(string start, string end) {

}

// print all node info
void BpTree::Print() {
	
	ofstream flog;
	flog.open("log.txt", ios::app);
	flog << "======= PRINT_BP =======\n";

	BpTreeNode* cur = root;
	while(cur->getMostLeftChild() != nullptr){	// go to most left datanode
		cur = cur->getMostLeftChild();
	}
	while(cur != nullptr){		// traverse all data node and datanode->mapdata
		for(auto i : *cur->getDataMap()){
			flog << i.second->GetUserName() << ' ' << i.second->GetVaccineName() << ' ' << i.second->GetTimes() << ' ' << i.second->GetAge() << ' ' << i.second->GetLocationName() << endl;
		}
		cur = cur->getNext();
	}

	flog << "========================\n";
	flog.close();
}

// if Jeopjong complete ? true : false;
bool BpTree::IsInoculationComplete(VaccinationData* data){

	// find data
	// if find == nullptr
	//	 -> return false
	// if get data
	// 	 -> get inoculate count
	VaccinationData* getData = FindVaccineData(data->GetUserName());
	if(getData == nullptr){
		return false;
	}
	else{
		if(getData->GetVaccineName() == "Pfizer"){
			if(getData->GetTimes() < 2)
				return false;
			else
				return true;
		}
		else if(getData->GetVaccineName() == "Moderna"){
			if(getData->GetTimes() < 2)
				return false;
			else
				return true;
		}
		else if(getData->GetVaccineName() == "AstraZeneca"){
			if(getData->GetTimes() < 2)
				return false;
			else
				return true;
		}
		else if(getData->GetVaccineName() == "Janssen"){
			if(getData->GetTimes() < 1)
				return false;
			else
				return true;
		}
		else{		// default => not keep in mind
			return false;
		}
	}

}

// Find data using name
VaccinationData* BpTree::FindVaccineData(string username){

	BpTreeNode* cur = root;
	while(cur->getMostLeftChild() != nullptr){	// go to most left data node
		cur = cur->getMostLeftChild();
	}
	while(cur != nullptr){
		for(auto i : *cur->getDataMap()){
			if(i.first == username){		//  found!!
				return i.second;
			}
		}
		cur = cur->getNext();
	}
	
	return nullptr;	// can't found
}

// alphabet means  username[0]
vector<VaccinationData*> BpTree::FindVaccineData_alphabet(string alphabet){

	vector<VaccinationData*> v;

	BpTreeNode* cur = root;
	while(cur->getMostLeftChild() != nullptr){
		cur = cur->getMostLeftChild();
	}
	while(cur != nullptr){
		for(auto i : *cur->getDataMap()){
			if(i.first[0] == alphabet[0]){			// found
				v.push_back(i.second);				// push back in vector
			}
		}
		cur = cur->getNext();						// keep finding until nullptr
	}
	
	return v;
}