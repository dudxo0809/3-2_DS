#include "Manager.h"
#include <iostream>

int main()
{
	Manager k(3);
	k.run("command.txt");
    return 0;
}

