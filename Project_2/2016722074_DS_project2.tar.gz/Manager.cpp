#include "Manager.h"
Manager::Manager(int bpOrder) {
	avl = new AVLTree;		// make new 2 data structure
	bp = new BpTree;

	bpflag = false;				// if LOAD => flag on
}

Manager::~Manager() {
	delete avl;						// deallocate heap memory
	delete bp;
}

void Manager::run(const char* command_txt) {
	
	fin.open(command_txt);

	if(!fin){
		flog.open("log.txt", ios::app);
		flog << "command file open error!\n";
		flog.close();
		return;
	}

	while(!fin.eof()){		// Loop until last command
		string cmd;
		fin >> cmd;
		// LOAD
		if(cmd == "LOAD"){
			if(LOAD()){
				flog.open("log.txt", ios::app);
				flog << "========LOAD========\n";
				flog << "Success\n";
				flog << "====================\n";
				flog.close();
			}
			else{		// print error
				printErrorCode(100);
			}
		}	// VLOAD
		else if(cmd == "VLOAD"){
			// AVL -> printvector
			if(avl->GetRoot() == nullptr){		// has no node in avl
				printErrorCode(200);
				continue;
			}
			avl->GetVector(Print_vector);		// avl to vector

			flog.open("log.txt", ios::app);
			flog << "========VLOAD========\n";
			flog << "Success\n";
			flog << "=====================\n";
			flog.close();

			
		}	//ADD
		else if(cmd == "ADD"){
			// Add data to B+ tree
			
			getline(fin, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
			v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
			// v[1] : name
			// v[2] : vaccine
			// v[3] : age
			// v[4] : city
			if(cnt != 5){
				printErrorCode(300);
				//cout << "parameter error\n";
				continue;
			}
			VaccinationData* newData = new VaccinationData;
			newData->SetUserName(v[1]);
			newData->SetVaccineName(v[2]);
			newData->SetAge(atoi(v[3].c_str()));
			newData->SetLocationName(v[4]);
			newData->SetTimes(1);

			if(!bp->Insert(newData)){		// if false -> alreay jeopjong finish
				printErrorCode(300);
				//cout << "Inoculation Complete!! \n";

				//avl->Insert(newData);
				//cout << avl->Search(newData->GetUserName())->GetUserName() << endl;
			}
			else{
				flog.open("log.txt", ios::app);
				flog << "======== ADD ========\n";
				flog << v[1] << ' ' << v[2] << ' ' << v[3] << ' ' << v[4] << endl;
				flog << "=====================\n";
				flog.close();
			}
			if(bp->IsInoculationComplete(newData) && !avl->Search(newData->GetUserName())){
				avl->Insert(newData);
				// if complete inoculation by this ADD command 
				// insert to avl
			}
		}	// SEARCH in B+-tree
		else if(cmd == "SEARCH_BP"){
			getline(fin, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
			v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);
			if(cnt == 2){
				if(!SEARCH_BP(v[1])){	// not found
					printErrorCode(400);
				}
			}
			else if(cnt == 3){				// parameter not enough
				if(!SEARCH_BP(v[1], v[2])){	// found nothing
					printErrorCode(400);
				}
			}
			else{
				printErrorCode(400);
			}
		}	// searching in avl
		else if(cmd == "SEARCH_AVL"){
			getline(fin, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
			v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);

			if(cnt != 2 || avl->GetRoot() == nullptr){	// not enough param or has no node in avl
				printErrorCode(500);
			}
			VaccinationData* getData = avl->Search(v[1]);
			if(getData == nullptr){		// not found
				printErrorCode(500);
			}
			else{		// found
				flog.open("log.txt", ios::app);
				flog << "====== SEARCH_AVL ======\n";
				flog << getData->GetUserName() << ' ' << getData->GetVaccineName() << ' ' 
				<< getData->GetTimes() << ' ' << getData->GetAge() << ' ' << getData->GetLocationName() << endl;
				flog << "========================\n";
				flog.close();
			}

		}	// Print vector
		else if(cmd == "VPRINT"){
			getline(fin, cmd);
			string v[10];
			// toknize command
			size_t prev = 0, current;
			current = cmd.find(' ');
			int cnt = 0;
			while(current != string::npos){
				string sub = cmd.substr(prev, current - prev);
				v[cnt] = sub;
				prev = current + 1;
				current = cmd.find(' ', prev);
				cnt++;
			}
			v[cnt++] = cmd.substr(prev, current - prev);
			v[cnt] = cmd.substr(prev, current - prev);

			if(avl->GetRoot() == nullptr || Print_vector.size() == 0){		// avl is empty or VLOAD never been called
				printErrorCode(600);
			}
			else{
				VPRINT(v[1]);	// parmeter is type A or B
			}
		}	// Print B+Tree data
		else if(cmd == "PRINT_BP"){
			if(bp->GetRoot() == nullptr){	// bp is empty
				printErrorCode(700);
			}
			else{
				bp->Print();		// print all data
			}
		}
		else if(cmd == "EXIT"){
			break;		// break while
		}
		else{
			printErrorCode(800);		// undefined command
		}
	}


	fin.close();
}

bool Manager::LOAD() {

	if(bpflag == true)
		return false;
	bpflag = true;
	// exception hndler 

	input_data.open("input_data.txt");
			
	while(!input_data.eof()){
		// get input data
		VaccinationData* newData = new VaccinationData;
		string name;
		string vaccin;	
		int count;
		int age;
		string city;
		input_data >> name;
		input_data >> vaccin;
		input_data >> count;
		input_data >> age;
		input_data >> city;
		newData->SetUserName(name);
		newData->SetVaccineName(vaccin);
		newData->SetTimes(count);
		newData->SetAge(age);
		newData->SetLocationName(city);

		bp->Insert(newData);
	}
	input_data.close();

	return true;
}

bool Manager::VLOAD() {
	avl->GetVector(Print_vector);
	
}

bool Manager::ADD() {

}

bool Manager::SEARCH_BP(string name) {
	VaccinationData* temp = bp->FindVaccineData(name);
	if(temp == nullptr){
		return false;
	}
	else{
		flog.open("log.txt", ios::app);
		flog << "======= SEARCH_BP =======\n";
		flog << temp->GetUserName() << ' ' << temp->GetVaccineName() << ' ' << temp->GetTimes()
		<< ' ' << temp->GetAge() << ' ' << temp->GetLocationName() << endl;
		flog << "=========================\n";
		flog.close();
		return true;
	}
}

bool Manager::SEARCH_BP(string start, string end) {

	int cnt = 0;

	

	for(char ch = start[0]; ch <= end[0]; ch++){
		string str;
		str += ch;
		
		vector<VaccinationData*> temp = bp->FindVaccineData_alphabet(str);
		cnt += temp.size();
	}
	if(cnt == 0){
		return false;
	}


	flog.open("log.txt", ios::app);
	flog << "======= SEARCH_BP =======\n";
	for(char ch = start[0]; ch <= end[0]; ch++){
		string str;
		str += ch;
		vector<VaccinationData*> temp = bp->FindVaccineData_alphabet(str);
		for(auto i : temp)
			flog << i->GetUserName() << ' ' << i->GetVaccineName() << ' ' << i->GetTimes() << ' ' << i->GetAge() << ' ' << i->GetLocationName() << endl;
		
	}
	flog << "=========================\n";
	flog.close();

	return true;
}

bool Manager::SEARCH_AVL(string name) {

}

bool Compare(VaccinationData* vac1, VaccinationData* vac2) {

}

bool Manager::PRINT_BP(){
	if(bp->GetRoot() == nullptr){
		//cout << "bp is null\n";
		return false;
	}
	else{
		//cout << "print bp\n";
		bp->Print();
		return true;
	}
}

bool Manager::VPRINT(string type_) {

	if(type_ == "A"){
		sort(Print_vector.begin(), Print_vector.end(), Pred_A);
	}
	else if(type_ == "B"){
		sort(Print_vector.begin(), Print_vector.end(), Pred_B);
	}

	flog.open("log.txt", ios::app);
	flog << "======= VPRINT " << type_ << " =======\n";
	for(auto i : Print_vector)
		flog << i->GetUserName() << ' ' << i->GetVaccineName() << ' ' << i->GetTimes() << ' ' << i->GetAge() << ' ' << i->GetLocationName() << endl;
	flog << "======================\n";
	flog.close();
	return true;
}

void Manager::printErrorCode(int n) {
	ofstream fout;
	fout.open("log.txt", ofstream::app);
	fout << "========== ERROR ==========" <<endl;
	fout << n << endl;
	fout << "===========================" << endl << endl;
	fout.close();
}

bool Pred_A(VaccinationData* a, VaccinationData* b){
	if(a->GetVaccineName() ==  b->GetVaccineName()){
		if(a->GetAge() == b->GetAge()){
			return a->GetUserName() < b->GetUserName();
		}
		else{
			return a->GetAge() < b->GetAge();
		}
	}
	else{
		return a->GetVaccineName() < b->GetVaccineName();
	}
}
bool Pred_B(VaccinationData* a, VaccinationData* b){
	if(a->GetLocationName() == b->GetLocationName()){
		if(a->GetAge() == b->GetAge()){
			return a->GetUserName() < b->GetUserName();
		}
		else{
			return a->GetAge() > b->GetAge();
		}
	}
	else{
		return a->GetLocationName() < b->GetLocationName();
	}
}