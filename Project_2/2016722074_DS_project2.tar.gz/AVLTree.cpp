#include "AVLTree.h"
bool AVLTree::Insert(VaccinationData* pVac){
    //  Set Vaccine count max
    if(pVac->GetVaccineName() == "Pfizer" || pVac->GetVaccineName() == "Moderna" || pVac->GetVaccineName() == "AstraZeneca"){
        pVac->SetTimes(2);
    }
    else if(pVac->GetVaccineName() == "Janssen"){
        pVac->SetTimes(1);
    }
    // new node is root
    if(root == NULL){
        AVLNode* newNode = new AVLNode;
        newNode->setVacData(pVac);
        root = newNode;
        
        return true;
    }
    AVLNode* a = root;
    AVLNode* pa = NULL;
    AVLNode* p = root;
    AVLNode* pp = NULL;
    AVLNode* rootSub = NULL;

    while(p!=NULL){
        if(p->getBF() != 0){a=p;pa=pp;}
        if(pVac->GetUserName() < p->getVacData()->GetUserName()){
            pp = p; p = p->getLeft();
        }
        else if(pVac->GetUserName() > p->getVacData()->GetUserName()){
            pp = p; p = p->getRight();
        }
        else{
            // already in tree
            // update jeopjong info
            p->setVacData(pVac); ///
            return true;
        }
    }

    AVLNode* newNode = new AVLNode;
    newNode->setVacData(pVac);
    if(pVac->GetUserName() < pp->getVacData()->GetUserName()){
        pp->setLeft(newNode);
    }
    else{
        pp->setRight(newNode);
    }

    int d;
    AVLNode* b,*c;

    if(pVac->GetUserName() > a->getVacData()->GetUserName()){
        p = a->getRight();
        b = p;
        d = -1;
    }
    else{
        p = a->getLeft(); 
        b = p;
        d = 1;
    }

    while(p!= newNode){
        if(pVac->GetUserName() > p->getVacData()->GetUserName()){
            p->setBF(-1); p = p->getRight();
        }
        else{
            p->setBF(1); p = p->getLeft();
        }
    }

    // Is tree unbalanced?
    if(a->getBF() == 0 || a->getBF() + d == 0){
        a->setBF(a->getBF() + d);
        return true;
    }

    // if Unbalance

    // LL
    if(d == 1){
        if(b->getBF() == 1){
            a->setLeft(b->getRight());
            b->setRight(a);
            a->setBF(0);
            b->setBF(0);
            rootSub = b;
        }
        else{   // LR
            c = b->getRight();
            b->setRight(c->getLeft());
            a->setLeft(c->getRight());
            c->setLeft(b);
            c->setRight(a);
            switch(c->getBF()){
                case 0:
                    b->setBF(0); a->setBF(0);
                    break;
                case 1:
                    a->setBF(-1); b->setBF(0);
                    break;
                case -1:
                    b->setBF(1); a->setBF(0);
                    break;
            }
            c->setBF(0);
            rootSub = c;
        }
    }
    else{
        if(b->getBF() == -1){   // RR
            a->setRight(b->getLeft());
            b->setLeft(a); a->setBF(0); b->setBF(0);
            rootSub = b;
        }
        else{   // RL
            c = b->getLeft();
            b->setLeft(c->getRight());
            a->setRight(c->getLeft());
            c->setRight(b);
            c->setLeft(a);
            switch(c->getBF()){
                case 0:
                    b->setBF(0); a->setBF(0);
                    break;
                case 1:
                    b->setBF(-1); a->setBF(0);
                    break;
                case -1:
                    a->setBF(1); b->setBF(0);
                    break;
            }
            c->setBF(0);
            rootSub = c;
        }
    }
    // Subtree with root b has been rebalanced
    if(pa == NULL){
        root = rootSub;
    }
    else if(a == pa->getLeft()){
        pa->setLeft(rootSub);
    }
    else{
        pa->setRight(rootSub);
    }
    return true;
}

void AVLTree::GetVector(vector<VaccinationData*>& v){
    // push back to v all AVL data
    queue<AVLNode*> q;
    q.push(root);

    
    v.clear();

    // BST!!
    while(!q.empty()){

        VaccinationData* data =  q.front()->getVacData();
        if(q.front()->getLeft() != nullptr)
            q.push(q.front()->getLeft());
        if(q.front()->getRight() != nullptr)
            q.push(q.front()->getRight());
        q.pop();
        
        v.push_back(data);
    }

}
    // seraching in tree
VaccinationData* AVLTree::Search(string name){
    AVLNode* cur = root;

    while(cur != nullptr){
        if(name == cur->getVacData()->GetUserName()){   // found!
            return cur->getVacData();
        }
        else if(name < cur->getVacData()->GetUserName()){ // go left
            cur = cur->getLeft();
        }
        else if(name > cur->getVacData()->GetUserName()){ // go right
            cur = cur->getRight();
        }
    }
    return nullptr;     // cant found
}

